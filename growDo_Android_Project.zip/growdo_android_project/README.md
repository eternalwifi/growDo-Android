# growDo Android project

This project wraps the supplied `growdo (1).html` app in a simple Android WebView container.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build finishes, use the notification's **Locate** link to find `app-debug.apk`.
6. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

## Important limitations
- This is a wrapper project, not a compiled APK.
- The supplied HTML stores accounts and tasks in browser `localStorage`. Data stays on that app installation/device and is not synchronized to a server.
- The HTML contains a demo account (`grower` / `password123`) and stores passwords directly in localStorage. This is not suitable for real private accounts. Remove demo credentials and implement secure backend authentication before using it for sensitive data.
- This project has not been built or tested with an Android SDK in this environment.
